// memhelper.cpp - root-side memory scanner for Android (arm64). Controlled by the app over stdin/stdout.
// Protocol: one command per line, fields separated by TAB.
// Reply: zero or more data lines (V/PS/PT/F/P), then exactly one "OK\t..." or "ERR\t..." line.
#include <algorithm>
#include <atomic>
#include <cctype>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <csignal>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <map>
#include <mutex>
#include <string>
#include <sys/stat.h>
#include <sys/types.h>
#include <thread>
#include <unistd.h>
#include <vector>

#ifndef MOD_PREFIX
#define MOD_PREFIX "/data/"   // only modules under this prefix count as "static" pointer bases
#endif

using u8 = uint8_t;
using u64 = uint64_t;

static std::string sf(const char* f, ...) {
    char b[2048];
    va_list ap;
    va_start(ap, f);
    vsnprintf(b, sizeof b, f, ap);
    va_end(ap);
    return b;
}
static void ok(const std::string& s = "") {
    if (s.empty()) fputs("OK\n", stdout); else fprintf(stdout, "OK\t%s\n", s.c_str());
    fflush(stdout);
}
static void err(const std::string& s) { fprintf(stdout, "ERR\t%s\n", s.c_str()); fflush(stdout); }
static void progress(int pct) { fprintf(stdout, "P\t%d\n", pct); fflush(stdout); }

static std::vector<std::string> split(const std::string& s, char c) {
    std::vector<std::string> o;
    size_t st = 0;
    for (;;) {
        size_t k = s.find(c, st);
        if (k == std::string::npos) { o.push_back(s.substr(st)); break; }
        o.push_back(s.substr(st, k - st));
        st = k + 1;
    }
    return o;
}

// ---------- value types ----------
enum Type { T_I8, T_I16, T_I32, T_I64, T_F32, T_F64, T_BAD };
enum Mode { M_EQ, M_RNG, M_INC, M_DEC, M_CHG, M_SAME, M_INCBY, M_DECBY, M_BAD };

static Type parseType(const std::string& s) {
    if (s == "i8") return T_I8;
    if (s == "i16") return T_I16;
    if (s == "i32") return T_I32;
    if (s == "i64") return T_I64;
    if (s == "f32") return T_F32;
    if (s == "f64") return T_F64;
    return T_BAD;
}
static Mode parseMode(const std::string& s) {
    if (s == "eq") return M_EQ;
    if (s == "rng") return M_RNG;
    if (s == "inc") return M_INC;
    if (s == "dec") return M_DEC;
    if (s == "chg") return M_CHG;
    if (s == "same") return M_SAME;
    if (s == "incby") return M_INCBY;
    if (s == "decby") return M_DECBY;
    return M_BAD;
}
static int typeSize(Type t) {
    switch (t) {
        case T_I8: return 1;
        case T_I16: return 2;
        case T_I32: case T_F32: return 4;
        case T_I64: case T_F64: return 8;
        default: return 0;
    }
}
static bool isFloat(Type t) { return t == T_F32 || t == T_F64; }

struct Num { int64_t i = 0; double d = 0; };

static Num decode(const u8* p, Type t) {
    Num n;
    switch (t) {
        case T_I8:  { int8_t v;  memcpy(&v, p, 1); n.i = v; break; }
        case T_I16: { int16_t v; memcpy(&v, p, 2); n.i = v; break; }
        case T_I32: { int32_t v; memcpy(&v, p, 4); n.i = v; break; }
        case T_I64: { int64_t v; memcpy(&v, p, 8); n.i = v; break; }
        case T_F32: { float v;   memcpy(&v, p, 4); n.d = v; break; }
        case T_F64: { double v;  memcpy(&v, p, 8); n.d = v; break; }
        default: break;
    }
    return n;
}
static void encode(const Num& n, Type t, u8* o) {
    switch (t) {
        case T_I8:  { int8_t v = (int8_t)n.i;   memcpy(o, &v, 1); break; }
        case T_I16: { int16_t v = (int16_t)n.i; memcpy(o, &v, 2); break; }
        case T_I32: { int32_t v = (int32_t)n.i; memcpy(o, &v, 4); break; }
        case T_I64: { int64_t v = n.i;          memcpy(o, &v, 8); break; }
        case T_F32: { float v = (float)n.d;     memcpy(o, &v, 4); break; }
        case T_F64: { double v = n.d;           memcpy(o, &v, 8); break; }
        default: break;
    }
}
static std::string fmtVal(const Num& n, Type t) {
    if (t == T_F32) return sf("%.7g", n.d);
    if (t == T_F64) return sf("%.15g", n.d);
    return sf("%lld", (long long)n.i);
}
static bool parseNum(const std::string& s, Type t, Num& out) {
    if (s.empty() || t == T_BAD) return false;
    const char* c = s.c_str();
    char* end = nullptr;
    errno = 0;
    if (isFloat(t)) {
        double d = strtod(c, &end);
        if (end == c || *end || errno == ERANGE || !std::isfinite(d)) return false;
        out.d = (t == T_F32) ? (double)(float)d : d;
        out.i = 0;
        return true;
    }
    const char* q = c + ((s[0] == '-' || s[0] == '+') ? 1 : 0);
    int base = (q[0] == '0' && (q[1] == 'x' || q[1] == 'X')) ? 16 : 10;
    long long v = strtoll(c, &end, base);
    if (end == c || *end || errno == ERANGE) return false;
    switch (t) {
        case T_I8:  if (v < -128 || v > 255) return false; v = (int8_t)v; break;
        case T_I16: if (v < -32768 || v > 65535) return false; v = (int16_t)v; break;
        case T_I32: if (v < INT32_MIN || v > (long long)UINT32_MAX) return false; v = (int32_t)v; break;
        default: break;
    }
    out.i = v;
    out.d = 0;
    return true;
}
static bool parseHex(const std::string& s, u64& v) {
    if (s.empty()) return false;
    const char* c = s.c_str();
    char* end = nullptr;
    errno = 0;
    v = strtoull(c, &end, 16);
    return !(end == c || *end || errno == ERANGE);
}
static int cmpNum(const Num& x, const Num& y, Type t) {
    if (isFloat(t)) return x.d < y.d ? -1 : (x.d > y.d ? 1 : 0);
    return x.i < y.i ? -1 : (x.i > y.i ? 1 : 0);
}
static bool matches(Mode m, Type t, const Num& cur, const Num& old, const Num& a, const Num& b) {
    if (isFloat(t) && !std::isfinite(cur.d)) return false;
    switch (m) {
        case M_EQ:   return cmpNum(cur, a, t) == 0;
        case M_RNG:  return cmpNum(cur, a, t) >= 0 && cmpNum(cur, b, t) <= 0;
        case M_INC:  return cmpNum(cur, old, t) > 0;
        case M_DEC:  return cmpNum(cur, old, t) < 0;
        case M_CHG:  return cmpNum(cur, old, t) != 0;
        case M_SAME: return cmpNum(cur, old, t) == 0;
        case M_INCBY:
        case M_DECBY: {
            bool up = (m == M_INCBY);
            if (isFloat(t)) {
                double want = up ? old.d + a.d : old.d - a.d;
                return std::fabs(cur.d - want) <= 1e-5 * std::fmax(1.0, std::fabs(want));
            }
            u64 w = up ? (u64)old.i + (u64)a.i : (u64)old.i - (u64)a.i;
            return cur.i == (int64_t)w;
        }
        default: return false;
    }
}

// ---------- target process ----------
static int g_pid = 0;
static int g_memfd = -1;
static bool g_readonly = false;
static u64 g_start = 0;
static std::string g_name;
static std::mutex g_fmu;   // guards g_memfd swaps and the freeze list

static inline u64 untag(u64 v) { return v & 0x0000FFFFFFFFFFFFULL; }  // strip ARM top-byte tags

static u64 readStartTime(int pid) {
    char path[64];
    snprintf(path, sizeof path, "/proc/%d/stat", pid);
    FILE* f = fopen(path, "r");
    if (!f) return 0;
    char buf[2048];
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    buf[n] = 0;
    char* p = strrchr(buf, ')');
    if (!p) return 0;
    p++;
    for (int i = 0; i < 19; i++) {           // skip fields 3..21, next token is field 22 (starttime)
        while (*p == ' ') p++;
        if (!*p) return 0;
        while (*p && *p != ' ') p++;
    }
    while (*p == ' ') p++;
    return strtoull(p, nullptr, 10);
}
static std::string cmdlineOf(int pid) {
    char path[64];
    snprintf(path, sizeof path, "/proc/%d/cmdline", pid);
    FILE* f = fopen(path, "r");
    if (!f) return "";
    char buf[512];
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    buf[n] = 0;
    std::string s(buf);
    for (char& c : s) if (c == '\t' || c == '\n') c = ' ';
    return s;
}

static bool readExact(u64 addr, void* buf, size_t len) {
    if (g_memfd < 0 || (addr >> 62)) return false;
    u8* p = (u8*)buf;
    size_t done = 0;
    while (done < len) {
        ssize_t r = pread(g_memfd, p + done, len - done, (off_t)(addr + done));
        if (r > 0) { done += (size_t)r; continue; }
        if (r < 0 && errno == EINTR) continue;
        return false;
    }
    return true;
}
static bool writeFd(int fd, u64 addr, const void* buf, size_t len) {
    if (fd < 0 || (addr >> 62)) return false;
    const u8* p = (const u8*)buf;
    size_t done = 0;
    while (done < len) {
        ssize_t r = pwrite(fd, p + done, len - done, (off_t)(addr + done));
        if (r > 0) { done += (size_t)r; continue; }
        if (r < 0 && errno == EINTR) continue;
        return false;
    }
    return true;
}
static bool writeExact(u64 addr, const void* buf, size_t len) {
    if (g_readonly) return false;
    return writeFd(g_memfd, addr, buf, len);
}

// ---------- maps / modules ----------
struct Region {
    u64 s, e;
    bool r, w, x, priv;
    std::string path, mod;
};
static std::vector<Region> g_regions;
static std::map<std::string, u64> g_modBase;   // basename -> lowest mapped address

static std::string baseName(const std::string& p) {
    size_t k = p.find_last_of('/');
    return k == std::string::npos ? p : p.substr(k + 1);
}
static bool startsWith(const std::string& s, const char* pre) { return s.rfind(pre, 0) == 0; }

static bool loadMaps() {
    g_regions.clear();
    g_modBase.clear();
    char p[64];
    snprintf(p, sizeof p, "/proc/%d/maps", g_pid);
    FILE* f = fopen(p, "r");
    if (!f) return false;
    char line[4096];
    while (fgets(line, sizeof line, f)) {
        unsigned long long s, e, off;
        char perms[8] = {0};
        if (sscanf(line, "%llx-%llx %7s %llx", &s, &e, perms, &off) != 4) continue;
        const char* q = line;
        for (int i = 0; i < 5; i++) {
            while (*q == ' ') q++;
            while (*q && *q != ' ' && *q != '\n') q++;
        }
        while (*q == ' ') q++;
        Region r;
        r.s = s; r.e = e;
        r.r = perms[0] == 'r'; r.w = perms[1] == 'w'; r.x = perms[2] == 'x'; r.priv = perms[3] == 'p';
        r.path = q;
        while (!r.path.empty() && (r.path.back() == '\n' || r.path.back() == '\r')) r.path.pop_back();
        if (e <= s) continue;
        if (!g_regions.empty() && !r.path.empty() && r.path[0] == '/') { /* nothing */ }
        if (!r.path.empty() && r.path[0] == '/') r.mod = r.path;
        else if ((r.path.empty() || r.path == "[anon:.bss]") && !g_regions.empty() &&
                 g_regions.back().e == r.s && !g_regions.back().mod.empty())
            r.mod = g_regions.back().mod;   // .bss placed right after its module
        g_regions.push_back(r);
    }
    fclose(f);
    for (const Region& r : g_regions) {
        if (r.path.empty() || r.path[0] != '/' || !startsWith(r.path, MOD_PREFIX)) continue;
        std::string b = baseName(r.path);
        auto it = g_modBase.find(b);
        if (it == g_modBase.end() || r.s < it->second) g_modBase[b] = r.s;
    }
    return !g_regions.empty();
}
static const Region* findRegion(u64 a) {
    size_t lo = 0, hi = g_regions.size();
    while (lo < hi) {
        size_t mid = (lo + hi) / 2;
        if (g_regions[mid].e <= a) lo = mid + 1; else hi = mid;
    }
    if (lo < g_regions.size() && g_regions[lo].s <= a && a < g_regions[lo].e) return &g_regions[lo];
    return nullptr;
}
static bool modOf(u64 a, std::string& mod, u64& off) {
    const Region* r = findRegion(a);
    if (!r || r->mod.empty() || !startsWith(r->mod, MOD_PREFIX)) return false;
    auto it = g_modBase.find(baseName(r->mod));
    if (it == g_modBase.end() || a < it->second) return false;
    mod = it->first;
    off = a - it->second;
    return true;
}
static bool addrMapped(u64 addr, int sz) {
    const Region* r = findRegion(addr);
    return r && r->r && addr + (u64)sz <= r->e;
}
static bool scannable(const Region& r) {
    if (!r.r || !r.w || !r.priv) return false;
    const std::string& p = r.path;
    if (p.empty()) return true;
    if (p == "[heap]" || startsWith(p, "[anon:")) return true;
    if (p[0] == '/') return startsWith(p, MOD_PREFIX);
    return false;
}

// ---------- scan state ----------
struct Cand { u64 addr; u64 old; };
static const size_t MAXC = 6000000;
static std::vector<Cand> g_cands;
static Type g_type = T_BAD;
static bool g_haveScan = false;

static bool needAttach() {
    if (g_pid <= 0 || g_memfd < 0) { err("not attached"); return false; }
    if (readStartTime(g_pid) != g_start) { err("target process is gone or restarted; attach again"); return false; }
    return true;
}

// ---------- freeze ----------
struct Freeze { u64 addr; Type t; u8 b[8]; int fails; };
static std::vector<Freeze> g_freeze;
static std::atomic<bool> g_run{true};

static void freezeLoop() {
    while (g_run) {
        std::this_thread::sleep_for(std::chrono::milliseconds(40));
        std::lock_guard<std::mutex> lk(g_fmu);
        if (g_freeze.empty() || g_memfd < 0 || g_readonly) continue;
        for (size_t i = 0; i < g_freeze.size();) {
            Freeze& z = g_freeze[i];
            if (writeFd(g_memfd, z.addr, z.b, typeSize(z.t))) z.fails = 0; else z.fails++;
            if (z.fails >= 25) g_freeze.erase(g_freeze.begin() + i); else i++;
        }
    }
}

// ---------- commands ----------
static void cmdPs() {
    DIR* d = opendir("/proc");
    if (!d) { err("cannot open /proc"); return; }
    int n = 0;
    while (dirent* e = readdir(d)) {
        if (!isdigit((unsigned char)e->d_name[0])) continue;
        int pid = atoi(e->d_name);
        if (pid <= 1) continue;
        char p[64];
        snprintf(p, sizeof p, "/proc/%d", pid);
        struct stat st;
        if (stat(p, &st) != 0) continue;
        unsigned appid = (unsigned)st.st_uid % 100000u;
        if (appid < 10000 || appid >= 20000) continue;
        std::string name = cmdlineOf(pid);
        if (name.empty()) continue;
        fprintf(stdout, "PS\t%d\t%s\n", pid, name.c_str());
        n++;
    }
    closedir(d);
    ok(sf("%d", n));
}

static void cmdAttach(const std::vector<std::string>& a) {
    if (a.size() < 2) { err("usage: attach pid"); return; }
    int pid = atoi(a[1].c_str());
    if (pid <= 1) { err("bad pid"); return; }
    u64 st = readStartTime(pid);
    if (!st) { err("process not found"); return; }
    char p[64];
    snprintf(p, sizeof p, "/proc/%d/mem", pid);
    bool ro = false;
    int fd = open(p, O_RDWR | O_CLOEXEC);
    if (fd < 0) { fd = open(p, O_RDONLY | O_CLOEXEC); ro = true; }
    if (fd < 0) { err(sf("cannot open %s: %s", p, strerror(errno))); return; }
    {
        std::lock_guard<std::mutex> lk(g_fmu);
        if (g_memfd >= 0) close(g_memfd);
        g_memfd = fd;
        g_readonly = ro;
        g_freeze.clear();
    }
    g_pid = pid; g_start = st; g_name = cmdlineOf(pid);
    g_cands.clear(); g_cands.shrink_to_fit();
    g_type = T_BAD; g_haveScan = false;
    if (!loadMaps()) { err("attached but cannot read maps"); return; }
    ok(sf("%s\t%s", g_name.c_str(), ro ? "readonly" : "rw"));
}

static void cmdReset() {
    g_cands.clear(); g_cands.shrink_to_fit();
    g_haveScan = false; g_type = T_BAD;
    ok("0");
}

static void cmdScan(const std::vector<std::string>& a) {   // scan type mode v1 [v2]
    if (!needAttach()) return;
    if (a.size() < 4) { err("usage: scan type mode v1 [v2]"); return; }
    Type t = parseType(a[1]);
    Mode m = parseMode(a[2]);
    if (t == T_BAD) { err("bad type"); return; }
    if (m != M_EQ && m != M_RNG) { err("first scan supports only eq and rng"); return; }
    Num v1, v2;
    if (!parseNum(a[3], t, v1)) { err("bad value (check the type: use f32/f64 for decimals)"); return; }
    if (m == M_RNG) {
        if (a.size() < 5 || !parseNum(a[4], t, v2)) { err("bad second value"); return; }
        if (cmpNum(v1, v2, t) > 0) std::swap(v1, v2);
    }
    if (!loadMaps()) { err("cannot read maps"); return; }
    const int sz = typeSize(t);
    g_cands.clear();
    g_cands.shrink_to_fit();
    g_cands.reserve(1 << 16);
    g_type = t;
    g_haveScan = false;
    u8 tb[8] = {0};
    bool fast = (m == M_EQ && !isFloat(t));
    if (fast) encode(v1, t, tb);
    u64 total = 0, done = 0;
    for (const Region& r : g_regions) if (scannable(r)) total += r.e - r.s;
    int lastPct = -1;
    bool trunc = false;
    const size_t CH = 1 << 20;
    std::vector<u8> buf(CH);
    for (const Region& r : g_regions) {
        if (!scannable(r) || trunc) continue;
        const u64 len = r.e - r.s;
        for (u64 off = 0; off < len && !trunc; off += CH) {
            size_t n = (size_t)std::min<u64>(CH, len - off);
            u64 base = r.s + off;
            size_t pages = (n + 4095) / 4096;
            std::vector<char> okp(pages, 1);
            if (!readExact(base, buf.data(), n)) {
                for (size_t pg = 0; pg < pages; pg++) {
                    size_t po = pg * 4096, pl = std::min<size_t>(4096, n - po);
                    okp[pg] = readExact(base + po, buf.data() + po, pl) ? 1 : 0;
                }
            }
            for (size_t pg = 0; pg < pages && !trunc; pg++) {
                if (!okp[pg]) continue;
                size_t po = pg * 4096, pe = std::min(n, po + 4096);
                for (size_t o = po; o + sz <= pe; o += sz) {
                    bool hit = fast ? (memcmp(buf.data() + o, tb, sz) == 0)
                                    : matches(m, t, decode(buf.data() + o, t), Num(), v1, v2);
                    if (!hit) continue;
                    if (g_cands.size() >= MAXC) { trunc = true; break; }
                    Cand c;
                    c.addr = base + o;
                    c.old = 0;
                    memcpy(&c.old, buf.data() + o, sz);
                    g_cands.push_back(c);
                }
            }
            done += n;
            int pct = total ? (int)(done * 100 / total) : 100;
            if (pct != lastPct) { progress(pct); lastPct = pct; }
        }
    }
    g_haveScan = true;
    ok(sf("%zu\t%d", g_cands.size(), trunc ? 1 : 0));
}

static void cmdNext(const std::vector<std::string>& a) {   // next mode [v1] [v2]
    if (!needAttach()) return;
    if (!g_haveScan || g_type == T_BAD) { err("no first scan yet"); return; }
    if (a.size() < 2) { err("usage: next mode [v1] [v2]"); return; }
    Mode m = parseMode(a[1]);
    if (m == M_BAD) { err("bad mode"); return; }
    const Type t = g_type;
    Num v1, v2;
    if (m == M_EQ || m == M_RNG || m == M_INCBY || m == M_DECBY) {
        if (a.size() < 3 || !parseNum(a[2], t, v1)) { err("bad value"); return; }
    }
    if (m == M_RNG) {
        if (a.size() < 4 || !parseNum(a[3], t, v2)) { err("bad second value"); return; }
        if (cmpNum(v1, v2, t) > 0) std::swap(v1, v2);
    }
    const int sz = typeSize(t);
    const u64 GROUP = 65536;
    std::vector<Cand> keep;
    keep.reserve(g_cands.size() / 2 + 16);
    std::vector<u8> buf;
    size_t n = g_cands.size(), i = 0;
    int lastPct = -1;
    while (i < n) {
        size_t j = i;
        u64 gs = g_cands[i].addr;
        while (j + 1 < n && g_cands[j + 1].addr + sz - gs <= GROUP) j++;
        u64 ge = g_cands[j].addr + sz;
        buf.resize((size_t)(ge - gs));
        bool whole = readExact(gs, buf.data(), buf.size());
        for (size_t k = i; k <= j; k++) {
            u8 cb[8] = {0};
            if (whole) memcpy(cb, buf.data() + (g_cands[k].addr - gs), sz);
            else if (!readExact(g_cands[k].addr, cb, sz)) continue;   // unreadable now: drop
            u8 ob[8];
            memcpy(ob, &g_cands[k].old, 8);
            if (matches(m, t, decode(cb, t), decode(ob, t), v1, v2)) {
                Cand c;
                c.addr = g_cands[k].addr;
                c.old = 0;
                memcpy(&c.old, cb, sz);
                keep.push_back(c);
            }
        }
        i = j + 1;
        int pct = (int)(i * 100 / n);
        if (pct != lastPct && pct % 5 == 0) { progress(pct); lastPct = pct; }
    }
    g_cands.swap(keep);
    ok(sf("%zu", g_cands.size()));
}

static void cmdRes(const std::vector<std::string>& a) {   // res start count
    if (!needAttach()) return;
    if (!g_haveScan) { ok("0"); return; }
    size_t start = a.size() > 1 ? (size_t)strtoull(a[1].c_str(), nullptr, 10) : 0;
    size_t cnt = a.size() > 2 ? (size_t)strtoull(a[2].c_str(), nullptr, 10) : 50;
    if (cnt > 200) cnt = 200;
    loadMaps();
    const int sz = typeSize(g_type);
    for (size_t i = start; i < g_cands.size() && i < start + cnt; i++) {
        const Cand& c = g_cands[i];
        u8 cur[8] = {0}, ob[8];
        std::string curS = "??";
        if (readExact(c.addr, cur, sz)) curS = fmtVal(decode(cur, g_type), g_type);
        memcpy(ob, &c.old, 8);
        std::string oldS = fmtVal(decode(ob, g_type), g_type);
        std::string mod = "-";
        u64 off = 0;
        if (!modOf(c.addr, mod, off)) { mod = "-"; off = 0; }
        fprintf(stdout, "V\t%llx\t%s\t%s\t%s\t%llx\n", (unsigned long long)c.addr, curS.c_str(), oldS.c_str(),
                mod.c_str(), (unsigned long long)off);
    }
    ok(sf("%zu", g_cands.size()));
}

static bool checkTarget(const std::string& addrS, const std::string& typeS, u64& addr, Type& t, std::string& why) {
    if (!parseHex(addrS, addr) || addr == 0) { why = "bad address"; return false; }
    t = parseType(typeS);
    if (t == T_BAD) { why = "bad type"; return false; }
    if (!loadMaps()) { why = "cannot read maps"; return false; }
    if (!addrMapped(addr, typeSize(t))) { why = "address is not in a mapped readable region"; return false; }
    return true;
}

static void cmdWrite(const std::vector<std::string>& a) {   // write addr type value
    if (!needAttach()) return;
    if (a.size() < 4) { err("usage: write addr type value"); return; }
    u64 addr; Type t; std::string why;
    if (!checkTarget(a[1], a[2], addr, t, why)) { err(why); return; }
    if (g_readonly) { err("memory opened read-only (root/SELinux denied write)"); return; }
    Num n;
    if (!parseNum(a[3], t, n)) { err("bad value"); return; }
    u8 b[8] = {0};
    encode(n, t, b);
    if (!writeExact(addr, b, typeSize(t))) { err(sf("write failed: %s", strerror(errno))); return; }
    u8 rb[8] = {0};
    if (!readExact(addr, rb, typeSize(t))) { err("written, but read-back failed"); return; }
    ok(sf("%s", fmtVal(decode(rb, t), t).c_str()));
}

static void cmdWriteAll(const std::vector<std::string>& a) {   // writeall type value
    if (!needAttach()) return;
    if (a.size() < 3) { err("usage: writeall type value"); return; }
    if (!g_haveScan) { err("no scan results"); return; }
    if (g_readonly) { err("memory opened read-only"); return; }
    Type t = parseType(a[1]);
    if (t != g_type) { err("type differs from the scan type"); return; }
    if (g_cands.size() > 5000) { err(sf("%zu results; refine below 5000 first", g_cands.size())); return; }
    Num n;
    if (!parseNum(a[2], t, n)) { err("bad value"); return; }
    u8 b[8] = {0};
    encode(n, t, b);
    int okc = 0, bad = 0;
    for (const Cand& c : g_cands) { if (writeExact(c.addr, b, typeSize(t))) okc++; else bad++; }
    ok(sf("%d\t%d", okc, bad));
}

static void cmdRead(const std::vector<std::string>& a) {   // read addr type
    if (!needAttach()) return;
    if (a.size() < 3) { err("usage: read addr type"); return; }
    u64 addr; Type t; std::string why;
    if (!checkTarget(a[1], a[2], addr, t, why)) { err(why); return; }
    u8 b[8] = {0};
    if (!readExact(addr, b, typeSize(t))) { err("read failed"); return; }
    ok(fmtVal(decode(b, t), t));
}

static void cmdFreeze(const std::vector<std::string>& a) {   // freeze addr type value
    if (!needAttach()) return;
    if (a.size() < 4) { err("usage: freeze addr type value"); return; }
    u64 addr; Type t; std::string why;
    if (!checkTarget(a[1], a[2], addr, t, why)) { err(why); return; }
    if (g_readonly) { err("memory opened read-only"); return; }
    Num n;
    if (!parseNum(a[3], t, n)) { err("bad value"); return; }
    Freeze z;
    memset(&z, 0, sizeof z);
    z.addr = addr; z.t = t; z.fails = 0;
    encode(n, t, z.b);
    std::lock_guard<std::mutex> lk(g_fmu);
    for (Freeze& e : g_freeze) if (e.addr == addr) { e = z; ok("updated"); return; }
    if (g_freeze.size() >= 256) { err("too many frozen addresses"); return; }
    g_freeze.push_back(z);
    ok("frozen");
}
static void cmdUnfreeze(const std::vector<std::string>& a) {
    u64 addr;
    if (a.size() < 2 || !parseHex(a[1], addr)) { err("usage: unfreeze addr"); return; }
    std::lock_guard<std::mutex> lk(g_fmu);
    for (size_t i = 0; i < g_freeze.size(); i++)
        if (g_freeze[i].addr == addr) { g_freeze.erase(g_freeze.begin() + i); ok("removed"); return; }
    ok("not frozen");
}
static void cmdUnfreezeAll() {
    std::lock_guard<std::mutex> lk(g_fmu);
    size_t n = g_freeze.size();
    g_freeze.clear();
    ok(sf("%zu", n));
}
static void cmdFrozen() {
    std::lock_guard<std::mutex> lk(g_fmu);
    for (const Freeze& z : g_freeze)
        fprintf(stdout, "F\t%llx\t%d\t%s\n", (unsigned long long)z.addr, (int)z.t, fmtVal(decode(z.b, z.t), z.t).c_str());
    ok(sf("%zu", g_freeze.size()));
}

static void cmdPtr(const std::vector<std::string>& a) {   // ptr targetHex maxoffHex
    if (!needAttach()) return;
    u64 target, maxoff;
    if (a.size() < 3 || !parseHex(a[1], target) || !parseHex(a[2], maxoff)) { err("usage: ptr target maxoff"); return; }
    target = untag(target);
    if (target < 0x10000) { err("target address too small"); return; }
    if (maxoff > 0x10000) { err("max offset above 0x10000 is not allowed (too noisy)"); return; }
    if (!loadMaps()) { err("cannot read maps"); return; }
    u64 lo = target > maxoff ? target - maxoff : 0, hi = target;
    struct PR { u64 addr, val; std::string mod; u64 off; };
    std::vector<PR> st, other;
    const size_t CAPS = 600, CAPO = 600;
    u64 total = 0, done = 0;
    for (const Region& r : g_regions) if (scannable(r)) total += r.e - r.s;
    int lastPct = -1;
    const size_t CH = 1 << 20;
    std::vector<u8> buf(CH);
    size_t nst = 0, noth = 0;
    for (const Region& r : g_regions) {
        if (!scannable(r)) continue;
        const u64 len = r.e - r.s;
        for (u64 off = 0; off < len; off += CH) {
            size_t n = (size_t)std::min<u64>(CH, len - off);
            u64 base = r.s + off;
            size_t pages = (n + 4095) / 4096;
            std::vector<char> okp(pages, 1);
            if (!readExact(base, buf.data(), n)) {
                for (size_t pg = 0; pg < pages; pg++) {
                    size_t po = pg * 4096, pl = std::min<size_t>(4096, n - po);
                    okp[pg] = readExact(base + po, buf.data() + po, pl) ? 1 : 0;
                }
            }
            for (size_t pg = 0; pg < pages; pg++) {
                if (!okp[pg]) continue;
                size_t po = pg * 4096, pe = std::min(n, po + 4096);
                for (size_t o = po; o + 8 <= pe; o += 8) {
                    u64 raw;
                    memcpy(&raw, buf.data() + o, 8);
                    u64 v = untag(raw);
                    if (v < lo || v > hi) continue;
                    u64 at = base + o;
                    if (at >= lo && at <= hi && at == target) continue;
                    std::string mod; u64 moff = 0;
                    bool isStatic = modOf(at, mod, moff);
                    if (isStatic) { nst++; if (st.size() < CAPS) st.push_back({at, raw, mod, moff}); }
                    else { noth++; if (other.size() < CAPO) other.push_back({at, raw, "-", 0}); }
                }
            }
            done += n;
            int pct = total ? (int)(done * 100 / total) : 100;
            if (pct != lastPct) { progress(pct); lastPct = pct; }
        }
    }
    for (const PR& p : st)
        fprintf(stdout, "PT\t%llx\t%llx\t%s\t%llx\n", (unsigned long long)p.addr, (unsigned long long)p.val, p.mod.c_str(), (unsigned long long)p.off);
    for (const PR& p : other)
        fprintf(stdout, "PT\t%llx\t%llx\t-\t0\n", (unsigned long long)p.addr, (unsigned long long)p.val);
    ok(sf("static=%zu(shown %zu) other=%zu(shown %zu)", nst, st.size(), noth, other.size()));
}

static void cmdResolve(const std::vector<std::string>& a) {   // resolve module baseHex off1,off2|-
    if (!needAttach()) return;
    u64 base;
    if (a.size() < 4 || !parseHex(a[2], base)) { err("usage: resolve module base offsets"); return; }
    if (!loadMaps()) { err("cannot read maps"); return; }
    auto it = g_modBase.find(a[1]);
    if (it == g_modBase.end()) { err("module '" + a[1] + "' is not loaded in the target"); return; }
    std::vector<u64> offs;
    if (a[3] != "-" && !a[3].empty()) {
        for (const std::string& s : split(a[3], ',')) {
            u64 o;
            if (!parseHex(s, o)) { err("bad offset list"); return; }
            offs.push_back(o);
        }
    }
    u64 p = it->second + base;
    for (size_t i = 0; i < offs.size(); i++) {
        u64 raw;
        if (!readExact(p, &raw, 8)) { err(sf("pointer read failed at step %zu (address %llx)", i + 1, (unsigned long long)p)); return; }
        u64 v = untag(raw);
        if (v < 0x10000) { err(sf("null/invalid pointer at step %zu (address %llx)", i + 1, (unsigned long long)p)); return; }
        p = v + offs[i];
    }
    if (!addrMapped(p, 1)) { err(sf("resolved address %llx is not mapped", (unsigned long long)p)); return; }
    ok(sf("%llx", (unsigned long long)p));
}

int main() {
    signal(SIGPIPE, SIG_IGN);
    setvbuf(stdout, nullptr, _IOFBF, 1 << 16);
    std::thread ft(freezeLoop);
    char* line = nullptr;
    size_t cap = 0;
    ssize_t n;
    while ((n = getline(&line, &cap, stdin)) > 0) {
        std::string s(line, (size_t)n);
        while (!s.empty() && (s.back() == '\n' || s.back() == '\r')) s.pop_back();
        if (s.empty()) continue;
        std::vector<std::string> a = split(s, '\t');
        const std::string& c = a[0];
        if (c == "ping") ok("pong");
        else if (c == "quit") break;
        else if (c == "ps") cmdPs();
        else if (c == "attach") cmdAttach(a);
        else if (c == "reset") cmdReset();
        else if (c == "scan") cmdScan(a);
        else if (c == "next") cmdNext(a);
        else if (c == "res") cmdRes(a);
        else if (c == "write") cmdWrite(a);
        else if (c == "writeall") cmdWriteAll(a);
        else if (c == "read") cmdRead(a);
        else if (c == "freeze") cmdFreeze(a);
        else if (c == "unfreeze") cmdUnfreeze(a);
        else if (c == "unfreezeall") cmdUnfreezeAll();
        else if (c == "frozen") cmdFrozen();
        else if (c == "ptr") cmdPtr(a);
        else if (c == "resolve") cmdResolve(a);
        else err("unknown command: " + c);
    }
    g_run = false;
    ft.join();
    free(line);
    return 0;
}
