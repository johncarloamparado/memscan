plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ritmada.memscan"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ritmada.memscan"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += "arm64-v8a" }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs {
            // libmemhelper.so is an executable, not a JNI library: it must be extracted to disk
            // so that root can run it, and it must not be stripped/modified.
            useLegacyPackaging = true
            keepDebugSymbols += "**/libmemhelper.so"
        }
    }
}
