package com.ritmada.memscan

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

data class Res(val addr: String, val cur: String, val old: String, val mod: String, val modOff: String)
data class Ptr(val addr: String, val value: String, val mod: String, val modOff: String)
data class Saved(val name: String, val type: String, val mod: String, val base: String, val offs: List<String>)

class MainActivity : Activity() {
    private val helper = Helper()
    private val io = Executors.newSingleThreadExecutor()
    private val page = 40
    private val tagMask = 0x0000FFFFFFFFFFFFL

    private lateinit var status: TextView
    private lateinit var procFilter: EditText
    private lateinit var procSpinner: Spinner
    private lateinit var typeSpinner: Spinner
    private lateinit var modeSpinner: Spinner
    private lateinit var v1: EditText
    private lateinit var v2: EditText
    private lateinit var resultsBox: LinearLayout
    private lateinit var pageInfo: TextView

    private var procs: List<Pair<Int, String>> = emptyList()
    private var curType = "i32"
    private var viewMode = 0          // 0 = scan results, 1 = pointer candidates
    private var pageStart = 0
    private var total = 0L

    private var ptrTarget = ""
    private var ptrType = "i32"
    private var ptrMaxOff = "400"
    private val chainDeltas = ArrayList<Long>()
    private var ptrRows: List<Ptr> = emptyList()

    private val saved = ArrayList<Saved>()

    // ---------------------------------------------------------------- UI helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit): Button = Button(this).apply {
        text = t
        setAllCaps(false)
        setOnClickListener { f() }
    }

    private fun row(vararg vs: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (v in vs) addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun spinner(items: Array<String>): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun edit(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        setSingleLine()
    }

    private fun item(t: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = t
        typeface = Typeface.MONOSPACE
        textSize = 12f
        setPadding(dp(6), dp(8), dp(6), dp(8))
        setBackgroundColor(0x11000000)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).also { it.bottomMargin = dp(4) }
    }

    private fun prompt(title: String, def: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.setText(def)
        et.setSingleLine()
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun menu(title: String, labels: List<String>, acts: List<() -> Unit>) {
        AlertDialog.Builder(this).setTitle(title)
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }.show()
    }

    private fun setStatus(s: String) = runOnUiThread { status.text = s }

    private fun bg(task: () -> Unit) {
        io.execute {
            try {
                task()
            } catch (e: Exception) {
                setStatus("Error: ${e.message}" + if (!helper.isRunning()) "  (helper stopped, tap Connect)" else "")
            }
        }
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("memscan", text))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun hexToLong(s: String): Long = java.lang.Long.parseUnsignedLong(s.removePrefix("0x"), 16)
    private fun toHex(v: Long): String = java.lang.Long.toHexString(v)

    // ---------------------------------------------------------------- lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSaved()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val sv = ScrollView(this).apply {
            fitsSystemWindows = true
            addView(root)
        }
        setContentView(sv)

        status = TextView(this).apply {
            text = "Not connected. Tap Connect (root) and allow it in SukiSU."
            typeface = Typeface.MONOSPACE
            textSize = 12f
        }
        root.addView(status)
        root.addView(row(btn("Connect (root)") { connect() }, btn("Saved") { showSaved() }, btn("Unfreeze all") { unfreezeAll() }))

        procFilter = edit("filter process name (optional)")
        procSpinner = Spinner(this)
        root.addView(procFilter)
        root.addView(row(btn("Refresh list") { refreshProcs() }, btn("Attach") { attach() }))
        root.addView(procSpinner)

        typeSpinner = spinner(arrayOf("i32", "f32", "i64", "f64", "i16", "i8"))
        modeSpinner = spinner(arrayOf("eq", "rng", "inc", "dec", "chg", "same", "incby", "decby"))
        v1 = edit("value (or range start / amount)")
        v2 = edit("range end (rng only)")
        root.addView(row(typeSpinner, modeSpinner))
        root.addView(v1)
        root.addView(v2)
        root.addView(row(btn("First scan") { firstScan() }, btn("Next scan") { nextScan() }, btn("Reset") { resetScan() }))

        pageInfo = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f }
        root.addView(pageInfo)
        root.addView(row(btn("Prev") { turnPage(-1) }, btn("Next") { turnPage(1) }, btn("Set ALL") { setAll() }))
        resultsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(resultsBox)
    }

    override fun onDestroy() {
        helper.stop()
        io.shutdownNow()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- connect / process
    private fun connect() {
        val filter = procFilter.text.toString()
        bg {
            setStatus("Requesting root... allow it in SukiSU if prompted.")
            val err = helper.start(this)
            if (err != null) { setStatus(err); return@bg }
            setStatus("Root helper ready.")
            loadProcs(filter)
        }
    }

    private fun refreshProcs() {
        val filter = procFilter.text.toString()
        bg { loadProcs(filter) }
    }

    private fun loadProcs(filter: String) {
        val r = helper.call("ps")
        if (!r.ok) { setStatus("ps failed: ${r.msg.joinToString()}"); return }
        val f = filter.trim().lowercase()
        val list = r.rows.mapNotNull { x ->
            val pid = x.getOrNull(1)?.toIntOrNull()
            val nm = x.getOrNull(2)
            if (x.getOrNull(0) == "PS" && pid != null && nm != null) pid to nm else null
        }.filter { f.isEmpty() || it.second.lowercase().contains(f) }
            .sortedBy { it.second.lowercase() }
        procs = list
        runOnUiThread {
            procSpinner.adapter = ArrayAdapter(
                this, android.R.layout.simple_spinner_dropdown_item, list.map { "${it.second} (${it.first})" }
            )
        }
        setStatus("${list.size} app processes. Open the game first, then pick it and tap Attach.")
    }

    private fun attach() {
        val idx = procSpinner.selectedItemPosition
        val p = procs.getOrNull(idx)
        if (p == null) { setStatus("Pick a process first."); return }
        bg {
            val r = helper.call("attach", p.first.toString())
            setStatus(if (r.ok) "Attached: ${r.msg.joinToString(" ")} (pid ${p.first})" else "Attach failed: ${r.msg.joinToString()}")
            runOnUiThread { resultsBox.removeAllViews(); pageInfo.text = "" }
        }
    }

    // ---------------------------------------------------------------- scanning
    private fun firstScan() {
        val t = typeSpinner.selectedItem as String
        val m = modeSpinner.selectedItem as String
        val a = v1.text.toString().trim()
        val b = v2.text.toString().trim()
        if (m != "eq" && m != "rng") { setStatus("First scan only supports eq and rng. Use eq with the number you see in game."); return }
        bg {
            val parts = mutableListOf("scan", t, m, a)
            if (m == "rng") parts.add(b)
            val r = helper.call(parts) { p -> setStatus("Scanning... $p%") }
            if (!r.ok) { setStatus("Scan failed: ${r.msg.joinToString()}"); return@bg }
            curType = t
            viewMode = 0
            val cnt = r.msg.getOrNull(0) ?: "?"
            val trunc = r.msg.getOrNull(1) == "1"
            setStatus("$cnt results" + if (trunc) " (TRUNCATED at the cap, use a more specific value or range)" else ". Change the value in game, then Next scan.")
            loadResults(0)
        }
    }

    private fun nextScan() {
        val m = modeSpinner.selectedItem as String
        val a = v1.text.toString().trim()
        val b = v2.text.toString().trim()
        bg {
            val parts = mutableListOf("next", m)
            if (m == "eq" || m == "rng" || m == "incby" || m == "decby") parts.add(a)
            if (m == "rng") parts.add(b)
            val r = helper.call(parts) { p -> setStatus("Filtering... $p%") }
            if (!r.ok) { setStatus("Next scan failed: ${r.msg.joinToString()}"); return@bg }
            viewMode = 0
            setStatus("${r.msg.getOrNull(0)} results left.")
            loadResults(0)
        }
    }

    private fun resetScan() {
        bg {
            helper.call("reset")
            viewMode = 0
            total = 0
            runOnUiThread { resultsBox.removeAllViews(); pageInfo.text = "" }
            setStatus("Scan cleared.")
        }
    }

    private fun loadResults(start: Int) {
        val r = helper.call("res", start.toString(), page.toString())
        if (!r.ok) { setStatus("Results failed: ${r.msg.joinToString()}"); return }
        pageStart = start
        total = r.msg.getOrNull(0)?.toLongOrNull() ?: 0
        val rows = r.rows.filter { it.getOrNull(0) == "V" && it.size >= 6 }.map { Res(it[1], it[2], it[3], it[4], it[5]) }
        runOnUiThread { renderScan(rows) }
    }

    private fun renderScan(rows: List<Res>) {
        resultsBox.removeAllViews()
        pageInfo.text = "Scan results ${pageStart + 1}-${pageStart + rows.size} of $total  [$curType]"
        for (r in rows) {
            val where = if (r.mod != "-") "\n  in ${r.mod}+0x${r.modOff}" else ""
            resultsBox.addView(item("${r.addr}   now=${r.cur}   was=${r.old}$where") { scanMenu(r) })
        }
    }

    private fun turnPage(dir: Int) {
        if (viewMode == 0) {
            val ns = pageStart + dir * page
            if (ns < 0 || ns >= total) return
            bg { loadResults(ns) }
        } else {
            val ns = pageStart + dir * page
            if (ns < 0 || ns >= ptrRows.size) return
            pageStart = ns
            renderPtr()
        }
    }

    private fun setAll() {
        if (viewMode != 0) { setStatus("Set ALL works on scan results."); return }
        prompt("Write to ALL $total results ($curType)", "") { v ->
            bg {
                val r = helper.call("writeall", curType, v)
                setStatus(if (r.ok) "Wrote ${r.msg.getOrNull(0)} ok, ${r.msg.getOrNull(1)} failed" else "Failed: ${r.msg.joinToString()}")
                loadResults(pageStart)
            }
        }
    }

    private fun scanMenu(r: Res) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add("Edit value"); acts.add {
            prompt("New $curType value", r.cur) { v ->
                bg {
                    val x = helper.call("write", r.addr, curType, v)
                    setStatus(if (x.ok) "Wrote, read back: ${x.msg.joinToString()}" else "Write failed: ${x.msg.joinToString()}")
                    loadResults(pageStart)
                }
            }
        }
        labels.add("Freeze value"); acts.add {
            prompt("Keep $curType at", r.cur) { v ->
                bg {
                    val x = helper.call("freeze", r.addr, curType, v)
                    setStatus(if (x.ok) "Freeze: ${x.msg.joinToString()} (${r.addr})" else "Freeze failed: ${x.msg.joinToString()}")
                }
            }
        }
        labels.add("Unfreeze"); acts.add {
            bg { val x = helper.call("unfreeze", r.addr); setStatus("Unfreeze: ${x.msg.joinToString()}") }
        }
        labels.add("Find pointers to this address"); acts.add {
            prompt("Max pointer offset (hex)", ptrMaxOff) { m ->
                ptrMaxOff = m
                ptrTarget = r.addr
                ptrType = curType
                chainDeltas.clear()
                bg { doPtrScan() }
            }
        }
        if (r.mod != "-") {
            labels.add("Save as static ${r.mod}+0x${r.modOff}"); acts.add {
                prompt("Name", "entry${saved.size + 1}") { n ->
                    addSaved(Saved(n, curType, r.mod, r.modOff, emptyList()))
                }
            }
        }
        labels.add("Copy address"); acts.add { copy(r.addr) }
        menu(r.addr, labels, acts)
    }

    // ---------------------------------------------------------------- pointer scan
    private fun doPtrScan() {
        setStatus("Pointer scan for $ptrTarget ...")
        val r = helper.call(listOf("ptr", ptrTarget, ptrMaxOff), 300_000) { p -> setStatus("Pointer scan... $p%") }
        if (!r.ok) { setStatus("Pointer scan failed: ${r.msg.joinToString()}"); return }
        ptrRows = r.rows.filter { it.getOrNull(0) == "PT" && it.size >= 5 }.map { Ptr(it[1], it[2], it[3], it[4]) }
        viewMode = 1
        pageStart = 0
        setStatus("Level ${chainDeltas.size + 1}: pointers to $ptrTarget. ${r.msg.joinToString(" ")}")
        runOnUiThread { renderPtr() }
    }

    private fun renderPtr() {
        resultsBox.removeAllViews()
        val end = minOf(ptrRows.size, pageStart + page)
        pageInfo.text = "Pointer candidates ${pageStart + 1}-$end of ${ptrRows.size}  target=$ptrTarget  level=${chainDeltas.size + 1}"
        val t = hexToLong(ptrTarget)
        for (i in pageStart until end) {
            val p = ptrRows[i]
            val delta = t - (hexToLong(p.value) and tagMask)
            val tag = if (p.mod != "-") "STATIC ${p.mod}+0x${p.modOff}" else "dynamic"
            resultsBox.addView(item("$tag\n  at ${p.addr} -> ${p.value}  offset=0x${toHex(delta)}") { ptrMenu(p, delta) })
        }
    }

    private fun ptrMenu(p: Ptr, delta: Long) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (p.mod != "-") {
            labels.add("Save chain (base ${p.mod}+0x${p.modOff})"); acts.add {
                prompt("Name", "entry${saved.size + 1}") { n ->
                    val offs = (chainDeltas + delta).reversed().map { toHex(it) }
                    addSaved(Saved(n, ptrType, p.mod, p.modOff, offs))
                }
            }
        }
        labels.add("Go deeper (find pointers to ${p.addr})"); acts.add {
            chainDeltas.add(delta)
            ptrTarget = p.addr
            bg { doPtrScan() }
        }
        labels.add("Copy address"); acts.add { copy(p.addr) }
        menu(p.addr, labels, acts)
    }

    // ---------------------------------------------------------------- saved entries
    private fun savedFile() = File(filesDir, "saved.txt")

    private fun loadSaved() {
        saved.clear()
        try {
            val f = savedFile()
            if (!f.exists()) return
            for (line in f.readLines()) {
                val x = line.split('\t')
                if (x.size < 5) continue
                saved.add(Saved(x[0], x[1], x[2], x[3], x[4].split(',').filter { it.isNotEmpty() }))
            }
        } catch (_: Exception) {
        }
    }

    private fun saveAll() {
        try {
            savedFile().writeText(saved.joinToString("\n") { "${it.name}\t${it.type}\t${it.mod}\t${it.base}\t${it.offs.joinToString(",")}" })
        } catch (e: Exception) {
            setStatus("Could not write saved.txt: ${e.message}")
        }
    }

    private fun addSaved(s: Saved) {
        val clean = s.name.replace('\t', ' ').replace('\n', ' ').ifEmpty { "entry" }
        saved.add(s.copy(name = clean))
        saveAll()
        setStatus("Saved '$clean': ${describe(s)}")
    }

    private fun describe(s: Saved): String {
        val chain = if (s.offs.isEmpty()) "" else " -> " + s.offs.joinToString(",") { "0x$it" }
        return "${s.mod}+0x${s.base}$chain"
    }

    private fun showSaved() {
        if (saved.isEmpty()) { Toast.makeText(this, "No saved offsets yet", Toast.LENGTH_SHORT).show(); return }
        val labels = saved.map { "${it.name} [${it.type}]\n${describe(it)}" }
        AlertDialog.Builder(this).setTitle("Saved offsets")
            .setItems(labels.toTypedArray()) { _, i -> savedMenu(saved[i]) }.show()
    }

    private fun resolveSaved(s: Saved): String? {
        val r = helper.call("resolve", s.mod, s.base, if (s.offs.isEmpty()) "-" else s.offs.joinToString(","))
        if (!r.ok) { setStatus("Resolve failed: ${r.msg.joinToString()}"); return null }
        return r.msg.firstOrNull()
    }

    private fun savedMenu(s: Saved) {
        val labels = listOf("Read now", "Write value", "Freeze value", "Copy as text", "Delete")
        val acts = listOf<() -> Unit>(
            {
                bg {
                    val a = resolveSaved(s) ?: return@bg
                    val r = helper.call("read", a, s.type)
                    setStatus(if (r.ok) "${s.name} @ $a = ${r.msg.joinToString()}" else "Read failed: ${r.msg.joinToString()}")
                }
            },
            {
                prompt("Write ${s.type} value", "") { v ->
                    bg {
                        val a = resolveSaved(s) ?: return@bg
                        val r = helper.call("write", a, s.type, v)
                        setStatus(if (r.ok) "${s.name} @ $a now ${r.msg.joinToString()}" else "Write failed: ${r.msg.joinToString()}")
                    }
                }
            },
            {
                prompt("Keep ${s.type} at", "") { v ->
                    bg {
                        val a = resolveSaved(s) ?: return@bg
                        val r = helper.call("freeze", a, s.type, v)
                        setStatus(if (r.ok) "${s.name} @ $a: ${r.msg.joinToString()}" else "Freeze failed: ${r.msg.joinToString()}")
                    }
                }
            },
            {
                copy(
                    "name=${s.name}\ntype=${s.type}\nmodule=${s.mod}\nbase_offset=0x${s.base}\n" +
                        "offsets=${s.offs.joinToString(",") { "0x$it" }}\n" +
                        "rule: p = module_base + base_offset; for each offset: p = read64(p) + offset; value at p\n"
                )
            },
            {
                saved.remove(s)
                saveAll()
                setStatus("Deleted '${s.name}'")
            }
        )
        menu(s.name, labels, acts)
    }

    private fun unfreezeAll() {
        bg {
            val r = helper.call("unfreezeall")
            setStatus("Unfroze ${r.msg.joinToString()}")
        }
    }
}
