package com.ritmada.memscan

import android.content.Context
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Talks to the root helper (libmemhelper.so) over stdin/stdout. Call only from one background thread. */
class Helper {
    class Reply(val ok: Boolean, val msg: List<String>, val rows: List<List<String>>)

    private var proc: Process? = null
    private var writer: OutputStream? = null
    private val q = LinkedBlockingQueue<String>()
    private val eof = "\u0000EOF"

    fun isRunning(): Boolean = proc?.isAlive == true

    /** Returns null on success, otherwise a human-readable error. */
    fun start(ctx: Context): String? {
        val lib = File(ctx.applicationInfo.nativeLibraryDir, "libmemhelper.so")
        if (!lib.exists()) return "Missing ${lib.absolutePath} (native lib was not extracted)"
        if (launch(lib.absolutePath)) return null
        stop()
        try {
            val p = ProcessBuilder(
                "su", "-c",
                "cp '${lib.absolutePath}' /data/local/tmp/memhelper && chmod 755 /data/local/tmp/memhelper"
            ).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            if (p.waitFor() != 0) return "Root copy step failed: $out"
        } catch (e: Exception) {
            return "su is not available: ${e.message}"
        }
        return if (launch("/data/local/tmp/memhelper")) null
        else "Helper did not answer. Root was denied, or running the binary is blocked."
    }

    private fun launch(path: String): Boolean {
        stop()
        return try {
            val p = ProcessBuilder("su", "-c", "exec '$path'").redirectErrorStream(true).start()
            proc = p
            writer = p.outputStream
            q.clear()
            Thread {
                try {
                    p.inputStream.bufferedReader().forEachLine { q.put(it) }
                } catch (_: Exception) {
                }
                q.put(eof)
            }.apply { isDaemon = true; start() }
            val r = call(listOf("ping"), 25_000)
            if (r.ok) true else { stop(); false }
        } catch (e: Exception) {
            stop()
            false
        }
    }

    fun stop() {
        try { writer?.write("quit\n".toByteArray()); writer?.flush() } catch (_: Exception) {}
        try { proc?.destroy() } catch (_: Exception) {}
        proc = null
        writer = null
    }

    fun call(vararg p: String): Reply = call(p.toList())

    fun call(cmd: List<String>, timeoutMs: Long = 120_000, onProgress: ((String) -> Unit)? = null): Reply {
        val w = writer
        if (!isRunning() || w == null) throw IOException("Not connected. Tap Connect.")
        w.write((cmd.joinToString("\t") + "\n").toByteArray())
        w.flush()
        val rows = ArrayList<List<String>>()
        while (true) {
            val line = q.poll(timeoutMs, TimeUnit.MILLISECONDS)
            if (line == null) { stop(); throw IOException("Helper timed out; disconnected.") }
            if (line == eof) { stop(); throw IOException("Helper exited (target closed or root revoked).") }
            val f = line.split('\t')
            when (f[0]) {
                "OK" -> return Reply(true, f.drop(1), rows)
                "ERR" -> return Reply(false, f.drop(1), rows)
                "P" -> onProgress?.invoke(f.getOrElse(1) { "" })
                else -> rows.add(f)
            }
        }
    }
}
